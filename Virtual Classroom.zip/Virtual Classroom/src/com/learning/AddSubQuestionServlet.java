package com.learning;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import db.DbConfig;

@WebServlet("/AddSubQuestion")
public class AddSubQuestionServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		HttpSession session=req.getSession();
		try {
			String descr=req.getParameter("descr");
			String tid=req.getParameter("tid");
			DbConfig.executeDML("insert into subquestions(descr,tid) values(?,?)",
					descr,tid);
			session.setAttribute("msg", "Question Added successfully");
			resp.sendRedirect("lecturer/subquestions.jsp?id="+tid);
		}
		catch(Exception ex) {
			System.err.println("Error "+ex.getMessage());
		}
	}

}
