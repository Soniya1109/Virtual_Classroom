package com.learning;

import java.io.IOException;
import java.util.Map;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import db.DbConfig;
import db.OLSHelper;

@WebServlet("/SubmitSubExam")
public class SubmitSubExamServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String tid=req.getParameter("tid");
		HttpSession session=req.getSession();
		String rollno=session.getAttribute("id").toString();
		Map<String,String[]> pp=req.getParameterMap();
		int total=0,correct=0;
		try {
		for(String key : pp.keySet()) {
			if(key.startsWith("ans")) {
				String qno=key.substring(3);
				String ans=pp.get(key)[0].toString();
				System.out.println(qno+ " => "+ans);
				DbConfig.executeDML("insert into subresult(rollno,tid,qid,ans,submitdate) "
						+ "values(?,?,?,?,date(now()))",rollno,tid,qno,ans);
			}
		}
		session.setAttribute("msg", "Test submitted successfully");
		resp.sendRedirect("student/subtests.jsp");
		}catch(Exception ex) {
			System.err.println("Error "+ex.getMessage());
		}
	}
}
