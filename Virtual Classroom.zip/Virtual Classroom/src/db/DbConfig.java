package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class DbConfig {

	/**
	 * common connection method to use in whole project
	 * @return
	 * @throws Exception
	 */
    public static Connection connect() throws Exception {
        Class.forName("com.mysql.jdbc.Driver");
        final String URL = "jdbc:mysql://localhost/online_learning";
        final String USER = "root";
        final String PWD = "anand";
        Connection con = DriverManager.getConnection(URL, USER, PWD);
        return con;
    }

    /**
     * find single record of a table on the basis of condition
     * @param table
     * @param condition
     * @return
     * @throws Exception
     */
    public static Map<String, String> findSingle(String table, String condition) throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT * FROM " + table + " WHERE " + condition);
        ResultSetMetaData rsm = rs.getMetaData();
        int cols = rsm.getColumnCount();
        HashMap<String, String> map = new HashMap<String, String>();
        rs.next();
        for (int i = 1; i <= cols; i++) {
            map.put(rsm.getColumnName(i), rs.getString(i));
        }
        con.close();
        return map;
    }
    
    /**
     * find the total no of records of a table
     * @param table
     * @return
     * @throws Exception
     */
    public static String findCount(String table) throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT count(*) FROM " + table);      
        rs.next();
        String result=rs.getString(1);
        con.close();
        return result;
    }
    
    /**
     * find the total no of records of a table
     * @param table
     * @return
     * @throws Exception
     */
    public static String findCount(String table,String condition) throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT count(*) FROM " + table+" WHERE "+condition);      
        rs.next();
        String result=rs.getString(1);
        con.close();
        return result;
    }

    /**
     * get all records of a table
     * @param table
     * @return
     * @throws Exception
     */
    public static List<Map<String, String>> allRecords(String table) throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT * FROM " + table);
        ResultSetMetaData rsm = rs.getMetaData();
        int cols = rsm.getColumnCount();
        List<Map<String, String>> list = new ArrayList<>();
        while (rs.next()) {
            Map<String,String> map=new HashMap<>();
            for (int i = 1; i <= cols; i++) {
                map.put(rsm.getColumnName(i), rs.getString(i));
            }
            list.add(map);
        }
        con.close();
        return list;
    }
    /**
     * list all records on the basis of condition from a table
     * @param table
     * @param condition
     * @return
     * @throws Exception
     */
    public static List<Map<String, String>> findall(String table,String condition) throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT * FROM " + table+" WHERE "+condition);
        ResultSetMetaData rsm = rs.getMetaData();
        int cols = rsm.getColumnCount();
        List<Map<String, String>> list = new ArrayList<>();
        while (rs.next()) {
            Map<String,String> map=new HashMap<>();
            for (int i = 1; i <= cols; i++) {
                map.put(rsm.getColumnName(i), rs.getString(i));
            }
            list.add(map);
        }
        con.close();
        return list;
    }
    
    /**
	 * execute Query
	 * @param sql
	 * @param params
	 * @return
	 */
	public static List<Map<String,String>> executeDQL(String sql,String ...params) throws Exception {
		Connection con=connect();
		PreparedStatement ps=con.prepareStatement(sql);
		for(int i=1;i<=params.length;i++) {
			ps.setString(i,params[i-1]);
		}
		ResultSet rs=ps.executeQuery();
		List<Map<String,String>> list=new ArrayList<Map<String,String>>();
		ResultSetMetaData rsm=rs.getMetaData();
        while(rs.next()){            
            Map<String,String> map=new HashMap<>();
            for(int i=1;i<=rsm.getColumnCount();i++){
                String colname=rsm.getColumnLabel(i);
                map.put(colname,rs.getString(colname));
            }
            list.add(map);
        }
		con.close();
		return list;
	}
	
	/**
	 * execute Query return single result
	 * @param sql
	 * @param params
	 * @return
	 */
	public static Map<String,String> executeDQLReturnSingle(String sql,String ...params) throws Exception {
		Connection con=connect();
		PreparedStatement ps=con.prepareStatement(sql);
		for(int i=1;i<=params.length;i++) {
			ps.setString(i,params[i-1]);
		}
		ResultSet rs=ps.executeQuery();
		Map<String,String> map=null;
		ResultSetMetaData rsm=rs.getMetaData();
        if(rs.next()){            
            map=new HashMap<>();
            for(int i=1;i<=rsm.getColumnCount();i++){
                String colname=rsm.getColumnLabel(i);
                map.put(colname,rs.getString(colname));
            }
        }
		con.close();
		return map;
	}
	
	/**
	 * execute Query return count
	 * @param sql
	 * @param params
	 * @return
	 */
	public static String singleValue(String sql,String ...params) throws Exception {
		Connection con=connect();
		PreparedStatement ps=con.prepareStatement(sql);
		for(int i=1;i<=params.length;i++) {
			ps.setString(i,params[i-1]);
		}
		ResultSet rs=ps.executeQuery();	
		String result=null;
        if(rs.next()){            
            result=rs.getString(1);
        }
		con.close();
		return result;
	}
    
    public static List<Map<String, String>> sublect() throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT * FROM subjects WHERE subid not in(SELECT subid from lecsub)");
        ResultSetMetaData rsm = rs.getMetaData();
        int cols = rsm.getColumnCount();
        List<Map<String, String>> list = new ArrayList<>();
        while (rs.next()) {
            Map<String,String> map=new HashMap<>();
            for (int i = 1; i <= cols; i++) {
                map.put(rsm.getColumnName(i), rs.getString(i));
            }
            list.add(map);
        }
        con.close();
        return list;
    }
    /**
     * list top 10 messages for the student
     * @param rollno
     * @return
     * @throws Exception
     */
    public static List<Map<String, String>> allmsgs(String rollno) throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT * FROM msgs WHERE lid in (SELECT lid from lecsub where subid in (SELECT subid FROM subjects WHERE cid=(SELECT class FROM student WHERE rollno="+rollno+"))) order by mdate desc");
        ResultSetMetaData rsm = rs.getMetaData();
        int cols = rsm.getColumnCount();
        List<Map<String, String>> list = new ArrayList<>();
        while (rs.next()) {
            Map<String,String> map=new HashMap<>();
            for (int i = 1; i <= cols; i++) {
                map.put(rsm.getColumnName(i), rs.getString(i));
            }
            list.add(map);
        }
        con.close();
        return list;
    }
    /**
     * list top 10 messages in lecturer login
     * @param lid
     * @return
     * @throws Exception
     */
    public static List<Map<String, String>> allLectmsgs(String lid) throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT * FROM msgs WHERE lid="+lid+" order by mdate desc limit 10 ");
        ResultSetMetaData rsm = rs.getMetaData();
        int cols = rsm.getColumnCount();
        List<Map<String, String>> list = new ArrayList<>();
        while (rs.next()) {
            Map<String,String> map=new HashMap<>();
            for (int i = 1; i <= cols; i++) {
                map.put(rsm.getColumnName(i), rs.getString(i));
            }
            list.add(map);
        }
        con.close();
        return list;
    }
    /**
     * list all material of a student
     * @param rollno
     * @return
     * @throws Exception
     */
    public static List<Map<String, String>> studentmat(String rollno) throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT * FROM material WHERE subid in (SELECT subid from subjects where cid=(SELECT class FROM student WHERE rollno="+rollno+"))");
        ResultSetMetaData rsm = rs.getMetaData();
        int cols = rsm.getColumnCount();
        List<Map<String, String>> list = new ArrayList<>();
        while (rs.next()) {
            Map<String,String> map=new HashMap<>();
            for (int i = 1; i <= cols; i++) {
                map.put(rsm.getColumnName(i), rs.getString(i));
            }
            list.add(map);
        }
        con.close();
        return list;
    }
    
    /**
     * list all tests of a student
     * @param rollno
     * @return
     * @throws Exception
     */
    public static List<Map<String, String>> studenttests(String rollno) throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT * FROM tests WHERE subid in (SELECT subid from subjects where cid=(SELECT class FROM student WHERE rollno="+rollno+")) order by 1 desc");
        ResultSetMetaData rsm = rs.getMetaData();
        int cols = rsm.getColumnCount();
        List<Map<String, String>> list = new ArrayList<>();
        while (rs.next()) {
            Map<String,String> map=new HashMap<>();
            for (int i = 1; i <= cols; i++) {
                map.put(rsm.getColumnName(i), rs.getString(i));
            }
            list.add(map);
        }
        con.close();
        return list;
    }
    
    /**
     * List subject of a lecturer
     * @param lid
     * @return
     * @throws Exception
     */
    public static List<Map<String, String>> lectsubs(String lid) throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT * FROM subjects WHERE subid in(SELECT subid from lecsub where lid="+lid+")");
        ResultSetMetaData rsm = rs.getMetaData();
        int cols = rsm.getColumnCount();
        List<Map<String, String>> list = new ArrayList<>();
        while (rs.next()) {
            Map<String,String> map=new HashMap<>();
            for (int i = 1; i <= cols; i++) {
                map.put(rsm.getColumnName(i), rs.getString(i));
            }
            list.add(map);
        }
        con.close();
        return list;
    }
    /**
     * Find the lecture list of a student
     * @param rollno
     * @return list of lecturers
     * @throws Exception
     */
    public static List<Map<String, String>> studentlects(String rollno) throws Exception {
        Connection con = connect();
        ResultSet rs = con.createStatement().executeQuery("SELECT lid,lname FROM lecturer WHERE lid in(SELECT lid from  lecsub where subid in (SELECT subid FROM subjects WHERE cid=(SELECT class FROM student WHERE rollno="+rollno+"))) and lid not in(SELECT lid from evaluation WHERE rollno="+rollno+")");
        ResultSetMetaData rsm = rs.getMetaData();
        int cols = rsm.getColumnCount();
        List<Map<String, String>> list = new ArrayList<>();
        while (rs.next()) {
            Map<String,String> map=new HashMap<>();
            for (int i = 1; i <= cols; i++) {
                map.put(rsm.getColumnName(i), rs.getString(i));
            }
            list.add(map);
        }
        con.close();
        return list;
    }
    
    /**
	 * Execute DML Statement Helper method
	 * @param sql
	 * @param params
	 * @throws Exception
	 */
	public static void executeDML(String sql,String ...params) throws Exception {
		Connection con=connect();
		PreparedStatement ps=con.prepareStatement(sql);
		for(int i=1;i<=params.length;i++) {
			ps.setString(i,params[i-1]);
		}
		ps.executeUpdate();
		con.close();
	}
    
	/**
	 * formtat the data in DD-MMM-YYYY format
	 * @param date
	 * @return
	 * @throws Exception
	 */
    public static String formatDate(String date) throws Exception {
		SimpleDateFormat sdf=new SimpleDateFormat("yyyy-MM-dd");
		String target=new SimpleDateFormat("dd-MMM-yyyy").format(sdf.parse(date));
		return target;
	}
	
    /***
     * format the data and time 
     * @param date
     * @return
     * @throws Exception
     */
    public static String formatDateTime(String date) throws Exception {
    	DateTimeFormatter fmt=DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String mdate=LocalDateTime.parse(date,fmt).format(DateTimeFormatter.ofPattern("dd-MMM-yyyy hh:mm a"));
    	return mdate;
    }
    /**
     * format the currency amount with indian currency
     * @param amount
     * @return
     */
	public static String formatMoney(long amount) {
		Locale lindia=new Locale("en","IN");
		NumberFormat india=NumberFormat.getCurrencyInstance(lindia);
		return india.format(amount).replace("Rs.", "&#8377; ");
	}
	/**
	 * get the today date in yyyy-MM-dd to use in input control
	 * @return
	 * @throws Exception
	 */
	public static String today() throws Exception {        
        String target = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        return target;
    }
}
